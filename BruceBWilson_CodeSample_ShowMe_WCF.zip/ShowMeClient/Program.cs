using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ShowMeClient.MyServiceReference;

namespace ShowMeClient
{
    class Program
    {
        static void Main(string[] args)
        {
            // Test Harness for WPF calls to WCF.
            int result;

            //Step 1: Create an instance of the WCF proxy.  
            DeviceClient client = new DeviceClient();

            // Step 2: Call the service operations.  

            // Call the ADO_InsertDevice service operation.
            result = client.ADO_InsertDevice("Mixer", 1);
            Console.WriteLine("ADO_InsertDevice: Result of operation: {0}", result);

            // Call the ADO_SelectDevice service operation.
            Console.Write("Enter the ID of the Device to return: ");
            int index = int.Parse(Console.ReadLine());
            Console.WriteLine("You pressed {0}", index);
            String deviceName;
            deviceName = client.ADO_SelectDevice(index);
            Console.WriteLine("ADO_SelectDevice: Device Name for id {0} = {1}", index, deviceName);

            // Call the ADO_UpdateDevice service operation.
            result = client.ADO_UpdateDevice(4, "Scale", 1);
            Console.WriteLine("ADO_UpdateDevice: Result of operation: {0}", result);

            // Call the ADO_DeleteDevice service operation.
            result = client.ADO_DeleteDevice(5);
            Console.WriteLine("ADO_DeleteDevice: Result of operation: {0}", result);

            // Call the ADO_ListDevice service operation.
            List<string> devices = client.ADO_ListDevice();
            Console.WriteLine("ADO_ListDevice: Result of operation...");
            foreach (string device in devices)
               {
                   Console.WriteLine("ADO_ListDevice: {0}", device);
               }
            
            //Step 3: Closing the client gracefully closes the connection and cleans up resources.  
            client.Close();

            Console.WriteLine("Press a key to quit");
            Console.ReadKey();
        }
    }
}
