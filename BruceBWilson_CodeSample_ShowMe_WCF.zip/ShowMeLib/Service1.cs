﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;

namespace ShowMeLib
{
    public class DeviceService : IDevice
    {
        public int ADO_InsertDevice(string name, int status)
        {
            // Connect to the database, query for passed parameters and return number of rows affected.
            int result;
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=ShowMe;User ID=WCFclient;Password=password2");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert Device (name, status) values('" + name + "', " + status.ToString() + ")", con);
            result = cmd.ExecuteNonQuery();
            con.Close();

            return result;
        }

        public string ADO_SelectDevice(int ID)
        {
            // Connect to the database, query for passed ID and return device data.
            String name = "Unknown";
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=ShowMe;User ID=WCFclient;Password=password2");
            con.Open();
            SqlCommand cmd = new SqlCommand("select name from Device where id = " + ID.ToString(), con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                name = reader.GetString(0);
            }
            con.Close();

            return name;
        }
        
        public int ADO_UpdateDevice(int ID, string name, int status)
        {
            // Connect to the database, query for passed parameters and return number of rows affected.
            int result;
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=ShowMe;User ID=WCFclient;Password=password2");
            con.Open();
            SqlCommand cmd = new SqlCommand("update Device set name = '" + name + "', status = " + status.ToString() + " where id = " + ID.ToString(), con);
            result = cmd.ExecuteNonQuery();
            con.Close();

            return result;
        }

        public int ADO_DeleteDevice(int ID)
        {
            // Connect to the database, query for passed parameters and return number of rows affected.
            int result;
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=ShowMe;User ID=WCFclient;Password=password2");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete Device where id = " + ID.ToString(), con);
            result = cmd.ExecuteNonQuery();
            con.Close();

            return result;
        }

        public List<string> ADO_ListDevice()
         {
            List<string> devices = new List<string>();

            // Connect to the database, query for passed ID and return device data.
            String name;
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=ShowMe;User ID=WCFclient;Password=password2");
            con.Open();
            SqlCommand cmd = new SqlCommand("select name from Device order by name", con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                name = reader.GetString(0);
                devices.Add(name);
            }
            con.Close();
            return devices;
        }
    }
}
