﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ShowMeLib
{
    [ServiceContract(Namespace = "http://Microsoft.ServiceModel.Samples")]
    public interface IDevice
    {
        [OperationContract]
        int ADO_InsertDevice(string name, int status);

        [OperationContract]
        string ADO_SelectDevice(int ID);

        [OperationContract]
        int ADO_UpdateDevice(int ID, string name, int status);

        [OperationContract]
        int ADO_DeleteDevice(int ID);

        [OperationContract]
        List<string> ADO_ListDevice();
     }
}
